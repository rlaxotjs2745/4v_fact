package kr.or.fact.api.model.DTO;

import lombok.Data;

@Data
public class LoginVO {
    String devicename;
    String username;
}
